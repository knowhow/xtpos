COMMENT ON COLUMN xtpos.reghist.reghist_taxauth_id IS 'Deprecated - DO NOT USE';
COMMENT ON COLUMN xtpos.saleitem.saleitem_tax_id IS 'Deprecated - DO NOT USE';
COMMENT ON COLUMN xtpos.saleitem.saleitem_tax_ratea IS 'Deprecated - DO NOT USE';
COMMENT ON COLUMN xtpos.saleitem.saleitem_tax_rateb IS 'Deprecated - DO NOT USE';
COMMENT ON COLUMN xtpos.saleitem.saleitem_tax_ratec IS 'Deprecated - DO NOT USE';
COMMENT ON COLUMN xtpos.saleitem.saleitem_tax_pcta IS 'Deprecated - DO NOT USE';
COMMENT ON COLUMN xtpos.saleitem.saleitem_tax_pctb IS 'Deprecated - DO NOT USE';
COMMENT ON COLUMN xtpos.saleitem.saleitem_tax_pctc IS 'Deprecated - DO NOT USE';